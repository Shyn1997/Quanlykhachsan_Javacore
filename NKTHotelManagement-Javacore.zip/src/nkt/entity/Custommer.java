package nkt.entity;

public class Custommer {
	private String name;
	private int yearOld;
	private String address;
	private String dOB;
	private int identityCard;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYearOld() {
		return yearOld;
	}
	public void setYearOld(int yearOld) {
		this.yearOld = yearOld;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getdOB() {
		return dOB;
	}

	public void setdOB(String dOB) {
		this.dOB = dOB;
	}
	public int getIdentityCard() {
		return identityCard;
	}
	public void setIdentityCard(int identityCard) {
		this.identityCard = identityCard;
	}

}
