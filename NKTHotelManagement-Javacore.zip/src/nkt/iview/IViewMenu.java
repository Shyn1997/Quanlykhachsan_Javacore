package nkt.iview;

public interface IViewMenu {
	public void menu();

	public void menuRoom();

	public void menuCustommer();

	public void menuTransaction();

	public void message(String message);

}
